#!/bin/bash
# Install dotfiles on a new machine
# Usage: cd ~/dotfiles && ./install.sh [--all|--shell|--emacs|--xresources|--scripts|--themes]
#   No args = install all

DOTFILES_DIR="$(cd "$(dirname "$0")" && pwd)"

detect_shell() {
    local user_shell
    user_shell=$(basename "$SHELL")
    case "$user_shell" in
        csh|tcsh) echo "csh" ;;
        *)        echo "bash" ;;
    esac
}

DETECTED_SHELL=$(detect_shell)

backup() {
    if [ -e "$1" ] && [ ! -L "$1" ]; then
        echo "  Backing up $1 -> $1.bak.$(date +%Y%m%d%H%M%S)"
        cp "$1" "$1.bak.$(date +%Y%m%d%H%M%S)"
    fi
}

install_shell() {
    echo "── Shell ($DETECTED_SHELL) ──"
    if [ "$DETECTED_SHELL" = "csh" ]; then
        backup ~/.cshrc
        if [ -f ~/.cshrc ]; then
            if ! grep -q "source ~/scripts/setup.csh" ~/.cshrc 2>/dev/null; then
                echo "" >> ~/.cshrc
                echo "# Added by dotfiles installer" >> ~/.cshrc
                echo "source ~/scripts/setup.csh" >> ~/.cshrc
                echo "  ✔ Added 'source ~/scripts/setup.csh' to ~/.cshrc"
            else
                echo "  ✔ ~/.cshrc already sources setup.csh (skipped)"
            fi
        else
            echo "# .cshrc" > ~/.cshrc
            echo "source ~/scripts/setup.csh" >> ~/.cshrc
            echo "  ✔ Created ~/.cshrc with setup.csh"
        fi
    else
        backup ~/.bashrc
        backup ~/.bash_profile
        cp "$DOTFILES_DIR/bashrc" ~/.bashrc
        cp "$DOTFILES_DIR/bash_profile" ~/.bash_profile
        echo "  ✔ bashrc, bash_profile"
    fi
}

install_emacs() {
    echo "── Emacs ──"
    backup ~/.emacs
    cp "$DOTFILES_DIR/emacs" ~/.emacs
    echo "  ✔ emacs"
}

install_xresources() {
    echo "── Xresources ──"
    backup ~/.Xresources.dracula
    cp "$DOTFILES_DIR/Xresources.dracula" ~/.Xresources.dracula
    if [ -n "$DISPLAY" ]; then
        xrdb ~/.Xresources.dracula 2>/dev/null
        echo "  ✔ Xresources.dracula (applied)"
    else
        echo "  ✔ Xresources.dracula (apply with: xrdb ~/.Xresources.dracula)"
    fi
}

install_scripts() {
    echo "── Scripts ──"
    mkdir -p ~/scripts
    cp "$DOTFILES_DIR/scripts/"* ~/scripts/
    chmod +x ~/scripts/*
    echo "  ✔ $(ls "$DOTFILES_DIR/scripts/" | wc -l) scripts installed to ~/scripts/"
}

install_themes() {
    echo "── GNOME Terminal Themes ──"
    if command -v dconf &>/dev/null; then
        bash "$DOTFILES_DIR/scripts/install_gnome_profiles.sh"
    else
        echo "  ✘ dconf not found, skipping terminal themes"
        echo "    Install later with: bash ~/scripts/install_gnome_profiles.sh"
    fi
}

show_usage() {
    echo "Usage: $0 [--all|--shell|--emacs|--xresources|--scripts|--themes]"
    echo ""
    echo "  --all          Install everything (default)"
    echo "  --shell        Install shell config (auto-detects bash/csh)"
    echo "  --emacs        Install emacs config"
    echo "  --xresources   Install Xresources.dracula"
    echo "  --scripts      Install ~/scripts/"
    echo "  --themes       Install GNOME Terminal themes"
    echo ""
    echo "Detected shell: $DETECTED_SHELL"
    echo ""
}

install_all() {
    echo ""
    echo "Installing dotfiles from $DOTFILES_DIR"
    echo "Detected shell: $DETECTED_SHELL"
    echo "══════════════════════════════════════════════"
    echo ""
    install_shell
    echo ""
    install_emacs
    echo ""
    install_xresources
    echo ""
    install_scripts
    echo ""
    install_themes
    echo ""
    echo "══════════════════════════════════════════════"
    if [ "$DETECTED_SHELL" = "csh" ]; then
        echo "Done. Run 'source ~/.cshrc' to activate."
    else
        echo "Done. Run 'source ~/.bashrc' to activate."
    fi
    echo ""
}

case "${1:---all}" in
    --all)         install_all ;;
    --shell)       install_shell ;;
    --emacs)       install_emacs ;;
    --xresources)  install_xresources ;;
    --scripts)     install_scripts ;;
    --themes)      install_themes ;;
    --help|-h)     show_usage ;;
    *)             echo "Unknown option: $1"; show_usage ;;
esac
