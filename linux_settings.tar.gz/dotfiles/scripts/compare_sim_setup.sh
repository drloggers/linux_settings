#!/bin/bash

DIR_A="/sync/mariana_jenkins_lustre/levikrua/lus4"
DIR_B="/sync/mariana_jenkins_lustre/borhadet/lustre_area"
MAX_DEPTH=7

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

TOTAL=0 IDENTICAL=0 DIFFERENT=0 MISSING=0

echo -e "\n${BOLD}================================================================${RESET}"
echo -e "${BOLD}  synopsys_sim.setup Comparison Report${RESET}"
echo -e "${BOLD}================================================================${RESET}"
echo -e "  Source : ${CYAN}${DIR_A}${RESET}"
echo -e "  Target : ${CYAN}${DIR_B}${RESET}"
echo -e "${BOLD}================================================================${RESET}\n"

for file_a in $(find "$DIR_A" -maxdepth $MAX_DEPTH -name 'synopsys_sim.setup' -type f 2>/dev/null | sort); do
    TOTAL=$((TOTAL + 1))
    rel_path="${file_a#${DIR_A}/}"
    file_b="${DIR_B}/${rel_path}"

    echo -e "${BOLD}----------------------------------------------------------------${RESET}"
    echo -e "  File: ${CYAN}${rel_path}${RESET}"
    echo -e "${BOLD}----------------------------------------------------------------${RESET}"

    if [[ ! -f "$file_b" ]]; then
        MISSING=$((MISSING + 1))
        echo -e "  Status: ${YELLOW}WARNING - MISSING in target${RESET}\n"
        continue
    fi

    if cmp -s "$file_a" "$file_b"; then
        IDENTICAL=$((IDENTICAL + 1))
        echo -e "  Status: ${GREEN}IDENTICAL${RESET}\n"
    else
        DIFFERENT=$((DIFFERENT + 1))
        echo -e "  Status: ${RED}DIFFERENT${RESET}\n"
        diff --color=always -u "$file_a" "$file_b" | tail -n +3
        echo ""
    fi
done

echo -e "${BOLD}================================================================${RESET}"
echo -e "${BOLD}  Summary${RESET}"
echo -e "${BOLD}================================================================${RESET}"
echo -e "  Total files found : ${BOLD}${TOTAL}${RESET}"
echo -e "  Identical         : ${GREEN}${IDENTICAL}${RESET}"
echo -e "  Different         : ${RED}${DIFFERENT}${RESET}"
echo -e "  Missing in target : ${YELLOW}${MISSING}${RESET}"
echo -e "${BOLD}================================================================${RESET}\n"
