#!/bin/csh
# CSH/TCSH equivalent of bash aliases
# Usage: source ~/scripts/setup.csh

# Basic aliases
alias ls 'ls -lha --color=auto'
alias grep 'grep --color=auto'
alias work 'cd /proj/maverick/borhadet'

# LSF-to-Slurm aliases
alias bjobs 'squeue -u $USER'
alias bjobs-w 'squeue -u $USER -o "%.18i %.9P %.50j %.8u %.8T %.10M %.6D %.20R"'
alias bjobs-l 'squeue -u $USER -l; echo "---"; scontrol show job -u $USER'
alias bkill 'scancel'
alias bsub 'sbatch -t 1-0 -c 24 --mem 256G --exclusive -p verif_ae sbatch_wrap.sh'
alias bsub8 'sbatch -t 1-0 -c 8 --mem 64G -p verif_ae sbatch_wrap.sh'
alias bsub16 'sbatch -t 1-0 -c 16 --mem 128G -p verif_ae sbatch_wrap.sh'
alias bsubi 'srun -t 1-0 -c 24 --mem 256G --exclusive -p verif_ae --pty bash'
alias bsubi8 'srun -t 1-0 -c 8 --mem 64G -p verif_ae --pty bash'
alias bsubi16 'srun -t 1-0 -c 16 --mem 128G -p verif_ae --pty bash'
alias bpeek 'tail -f slurm-\!:1.out'

# Xterm aliases
alias x '~/scripts/xterm.sh'
alias x8 '~/scripts/xterm8.sh'
alias x16 '~/scripts/xterm16.sh'

# Tools
alias runsim 'runsim -partition verif_ae'
alias ss 'source $MLATOOLS_HOME/verif/env/setup'
alias mla 'mla_wa -p maverick'
alias setvcs 'emacs $SOC_ROOT/verif-common/env/project/maverick/modules &'
alias e 'emacs \!* &'

setenv PATH ~/scripts/:$PATH
setenv SNPSLMD_LICENSE_FILE 27020@snpsLicense01.mla.annapurna.aws.a2z.com

module load mla_tools
module load slurm
module load synopsys/vcs/X-2025.06-SP2
module load synopsys/verdi/X-2025.06-SP2

xrdb ~/.Xresources.dracula
