#!/usr/bin/env python3
"""
Script to summarize simulation log file and extract transaction/stimulus information
"""

import re
import sys

def analyze_log(logfile):
    """Analyze log file and extract key information"""
    
    summary = {
        'test_name': None,
        'random_seed': None,
        'num_txn_ib': None,
        'num_txn_ob': None,
        'total_lines': 0,
        'uvm_phases': [],
        'transactions': [],
        'stimulus': [],
        'errors': [],
        'warnings': [],
        'test_result': None
    }
    
    print(f"Analyzing log file: {logfile}")
    print("=" * 80)
    
    try:
        with open(logfile, 'r') as f:
            for line_num, line in enumerate(f, 1):
                summary['total_lines'] += 1
                
                # Extract test configuration
                if 'ntb_random_seed' in line:
                    match = re.search(r'ntb_random_seed=(\d+)', line)
                    if match:
                        summary['random_seed'] = match.group(1)
                
                if 'UVM_TESTNAME' in line:
                    match = re.search(r'UVM_TESTNAME=(\w+)', line)
                    if match:
                        summary['test_name'] = match.group(1)
                
                if 'NUM_TXN_IB=' in line:
                    match = re.search(r'NUM_TXN_IB=(\d+)', line)
                    if match:
                        summary['num_txn_ib'] = match.group(1)
                
                if 'NUM_TXN_OB=' in line:
                    match = re.search(r'NUM_TXN_OB=(\d+)', line)
                    if match:
                        summary['num_txn_ob'] = match.group(1)
                
                # Extract UVM phases
                if 'UVM_INFO' in line and '_phase' in line:
                    if any(phase in line for phase in ['build_phase', 'connect_phase', 'end_of_elaboration_phase', 
                                                        'start_of_simulation_phase', 'run_phase', 'extract_phase',
                                                        'check_phase', 'report_phase', 'final_phase']):
                        summary['uvm_phases'].append((line_num, line.strip()))
                
                # Extract transaction information
                if any(keyword in line for keyword in ['transaction', 'TRANSACTION', 'xactn', 'XACTN']):
                    summary['transactions'].append((line_num, line.strip()))
                
                # Extract stimulus information
                if any(keyword in line for keyword in ['stimulus', 'STIMULUS', 'sequence', 'SEQUENCE', 
                                                       'write', 'WRITE', 'read', 'READ']):
                    if 'UVM_INFO' in line or 'INFO' in line:
                        summary['stimulus'].append((line_num, line.strip()))
                
                # Extract errors
                if 'UVM_ERROR' in line or 'ERROR' in line:
                    summary['errors'].append((line_num, line.strip()))
                
                # Extract warnings
                if 'UVM_WARNING' in line or 'WARNING' in line:
                    summary['warnings'].append((line_num, line.strip()))
                
                # Check test result
                if 'UVM_INFO' in line and ('TEST PASSED' in line or 'PASSED' in line):
                    summary['test_result'] = 'PASSED'
                elif 'UVM_ERROR' in line or 'UVM_FATAL' in line:
                    if summary['test_result'] != 'PASSED':
                        summary['test_result'] = 'FAILED'
    
    except FileNotFoundError:
        print(f"ERROR: File not found: {logfile}")
        return None
    except Exception as e:
        print(f"ERROR: {e}")
        return None
    
    return summary

def print_summary(summary):
    """Print summary to console"""
    
    print("\n" + "=" * 80)
    print("LOG FILE SUMMARY")
    print("=" * 80)
    
    print(f"\nTest Name: {summary['test_name']}")
    print(f"Random Seed: {summary['random_seed']}")
    print(f"Inbound Transactions (NUM_TXN_IB): {summary['num_txn_ib']}")
    print(f"Outbound Transactions (NUM_TXN_OB): {summary['num_txn_ob']}")
    print(f"Total Lines: {summary['total_lines']}")
    print(f"Test Result: {summary['test_result']}")
    
    print(f"\nUVM Phases Found: {len(summary['uvm_phases'])}")
    print(f"Transaction Messages: {len(summary['transactions'])}")
    print(f"Stimulus Messages: {len(summary['stimulus'])}")
    print(f"Errors: {len(summary['errors'])}")
    print(f"Warnings: {len(summary['warnings'])}")

def write_detailed_output(summary, output_file):
    """Write detailed output to file"""
    
    with open(output_file, 'w') as f:
        f.write("=" * 80 + "\n")
        f.write("SIMULATION LOG ANALYSIS\n")
        f.write("=" * 80 + "\n\n")
        
        f.write("CONFIGURATION\n")
        f.write("-" * 80 + "\n")
        f.write(f"Test Name: {summary['test_name']}\n")
        f.write(f"Random Seed: {summary['random_seed']}\n")
        f.write(f"Inbound Transactions: {summary['num_txn_ib']}\n")
        f.write(f"Outbound Transactions: {summary['num_txn_ob']}\n")
        f.write(f"Total Lines: {summary['total_lines']}\n")
        f.write(f"Test Result: {summary['test_result']}\n\n")
        
        f.write("=" * 80 + "\n")
        f.write("UVM PHASES\n")
        f.write("=" * 80 + "\n")
        for line_num, line in summary['uvm_phases']:
            f.write(f"[Line {line_num}] {line}\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("TRANSACTIONS (First 100)\n")
        f.write("=" * 80 + "\n")
        for line_num, line in summary['transactions'][:100]:
            f.write(f"[Line {line_num}] {line}\n")
        
        if len(summary['transactions']) > 100:
            f.write(f"\n... and {len(summary['transactions']) - 100} more transaction messages\n")
        
        f.write("\n" + "=" * 80 + "\n")
        f.write("STIMULUS (First 100)\n")
        f.write("=" * 80 + "\n")
        for line_num, line in summary['stimulus'][:100]:
            f.write(f"[Line {line_num}] {line}\n")
        
        if len(summary['stimulus']) > 100:
            f.write(f"\n... and {len(summary['stimulus']) - 100} more stimulus messages\n")
        
        if summary['errors']:
            f.write("\n" + "=" * 80 + "\n")
            f.write("ERRORS\n")
            f.write("=" * 80 + "\n")
            for line_num, line in summary['errors']:
                f.write(f"[Line {line_num}] {line}\n")
        
        if summary['warnings']:
            f.write("\n" + "=" * 80 + "\n")
            f.write("WARNINGS (First 50)\n")
            f.write("=" * 80 + "\n")
            for line_num, line in summary['warnings'][:50]:
                f.write(f"[Line {line_num}] {line}\n")
            
            if len(summary['warnings']) > 50:
                f.write(f"\n... and {len(summary['warnings']) - 50} more warnings\n")

def main():
    logfile = "sim.log"
    output_file = "summary.txt"
    
    # Analyze log
    summary = analyze_log(logfile)
    
    if summary:
        # Print summary to console
        print_summary(summary)
        
        # Write detailed output
        write_detailed_output(summary, output_file)
        
        print(f"\n{'=' * 80}")
        print(f"Detailed output written to: {output_file}")
        print(f"{'=' * 80}\n")
    else:
        print("Failed to analyze log file")
        sys.exit(1)

if __name__ == "__main__":
    main()
