#!/usr/bin/env python
"""
Get all possible drivers for a signal using Synopsys NPI (KDB).

Features:
- Handles 32-bit arrays and structs
- Traverses individual bits of buses
- Detects if any value was forced on the signal or its drivers
- Works with netlist model (driver_list) and lang model (force statements)

Usage:
  python get_signal_drivers.py -dbdir <daidir> -sig <signal_full_hierarchy_name> [options]

  Example:
  python get_signal_drivers.py -dbdir cpu_simv.daidir -sig tb_CPUsystem.i_CPUsystem.i_CPU.i_ALUB.IXR
  python get_signal_drivers.py -dbdir cpu_simv.daidir -sig tb_CPUsystem.i_CPUsystem.i_CPU.i_ALUB.IXR[1]
"""

import sys
import os
import argparse
from collections import OrderedDict

# Import pynpi
pynpi_lib_path = os.environ.get("VERDI_HOME", "") + "/share/NPI/python"
if pynpi_lib_path and os.path.exists(pynpi_lib_path):
    sys.path.append(os.path.abspath(pynpi_lib_path))
else:
    print("Error: VERDI_HOME not set or NPI not found. Please set VERDI_HOME.")
    sys.exit(1)

import pynpi.npisys as npisys
import pynpi.lang as lang
import pynpi.lang_l0 as lang_l0
import pynpi.netlist as nl


def get_nets_to_traverse(nl_net):
    """
    Get list of nets to traverse for driver analysis.
    Handles: scalar, bus (bit-blast), arrays, structs (slice_net_list).
    """
    nets = []
    if nl_net is None:
        return nets

    try:
        net_size = nl_net.size()
    except Exception:
        net_size = 1

    if net_size > 1:
        # Bus - traverse each bit
        left = nl_net.left()
        right = nl_net.right()
        for i in range(net_size):
            if left <= right:
                idx = left + i
            else:
                idx = right + i
            try:
                bit_net = nl_net.index(idx)
                if bit_net:
                    nets.append((bit_net, "[{0}]".format(idx)))
            except Exception:
                pass
    else:
        # Scalar or single-bit
        nets.append((nl_net, ""))

    return nets


def get_driver_info(drv_pin, visited_drivers, depth=0, max_depth=100):
    """
    Recursively collect driver information from a driver pin.
    Returns dict with: type, name, src_info, is_literal, connected_net, sub_drivers
    """
    if depth > max_depth:
        return None

    # Use object id for hashing (handles may not be hashable)
    try:
        drv_id = id(drv_pin.cps_obj) if hasattr(drv_pin, 'cps_obj') else id(drv_pin)
    except Exception:
        drv_id = id(drv_pin)
    if drv_id in visited_drivers:
        return None
    visited_drivers.add(drv_id)

    info = {
        "pin_name": drv_pin.full_name() if hasattr(drv_pin, 'full_name') else str(drv_pin),
        "pin_type": drv_pin.type() if hasattr(drv_pin, 'type') else "unknown",
        "direction": drv_pin.direction() if hasattr(drv_pin, 'direction') else "unknown",
        "src_info": "",
        "cell_type": "",
        "is_literal": False,
        "literal_value": None,
        "connected_net": None,
        "sub_drivers": [],
    }

    try:
        par_hdl = drv_pin.parent() if hasattr(drv_pin, 'parent') else None
        if not par_hdl:
            par_hdl = drv_pin
        inst_hdl = par_hdl.scope_inst() if hasattr(par_hdl, 'scope_inst') else None
        if inst_hdl:
            info["src_info"] = inst_hdl.src_info() if hasattr(inst_hdl, 'src_info') else ""
            info["cell_type"] = inst_hdl.cell_type() if hasattr(inst_hdl, 'cell_type') else ""
    except Exception:
        pass

    # Get connected net and check for literal/constant
    try:
        conn_net = drv_pin.connected_net() if hasattr(drv_pin, 'connected_net') else None
        if conn_net:
            net_names = conn_net.actual_name_list() if hasattr(conn_net, 'actual_name_list') else []
            info["connected_net"] = net_names[0] if net_names else str(conn_net)
            info["is_literal"] = conn_net.is_literal() if hasattr(conn_net, 'is_literal') else False
            if info["is_literal"] and hasattr(conn_net, 'value'):
                try:
                    info["literal_value"] = conn_net.value(nl.ValueFormat.HEX)
                except Exception:
                    pass

            # Recursively get drivers of this net (unless it's a register/literal)
            if info["cell_type"] == 'npiNlFlipFlopCell':
                info["sub_drivers"] = []  # Stop at register
            elif not info["is_literal"]:
                try:
                    # Get the input pins that drive this driver's output
                    # The connected_net is what this pin outputs - we need to find what drives the INPUT pins
                    if inst_hdl and hasattr(inst_hdl, 'driver_instport_list'):
                        input_driver_ports = inst_hdl.driver_instport_list()
                        for inp_port in input_driver_ports:
                            try:
                                inp_net = inp_port.connected_net() if hasattr(inp_port, 'connected_net') else None
                                if inp_net and hasattr(inp_net, 'driver_list'):
                                    inp_drv_list = inp_net.driver_list()
                                    for inp_drv in inp_drv_list:
                                        sub_info = get_driver_info(inp_drv, visited_drivers, depth + 1, max_depth)
                                        if sub_info:
                                            info["sub_drivers"].append(sub_info)
                            except Exception:
                                pass
                except Exception:
                    pass
    except Exception:
        pass

    return info


def print_driver_tree(info, indent=0, bit_suffix="", visited=None, driver_num=None):
    """Print driver information in a tree format."""
    if visited is None:
        visited = set()
   
    # Avoid infinite loops
    pin_id = info.get('pin_name', '')
    if pin_id in visited:
        print("{0}[ALREADY SHOWN ABOVE: {1}]".format("  " * indent, pin_id))
        return
    visited.add(pin_id)
   
    # Print current driver
    indent_str = "  " * indent
    if indent == 0 and driver_num is not None:
        arrow = "DRIVER #{0}: ".format(driver_num)
    elif indent > 0:
        arrow = "|- "
    else:
        arrow = ""
   
    pin_name = info.get('pin_name', 'unknown')
    pin_type = info.get('pin_type', 'unknown')
    cell_type = info.get('cell_type', '')
    src_info = info.get('src_info', '')
    connected_net = info.get('connected_net', '')
    is_literal = info.get('is_literal', False)
    literal_value = info.get('literal_value', '')
   
    # Format the main line
    print("{0}{1}{2}".format(indent_str, arrow, pin_name))
   
    # Add details with increased indent
    detail_indent = "  " * (indent + 1)
    if cell_type:
        cell_display = cell_type.replace('npiNl', '').replace('Cell', '')
        print("{0}Cell Type: {1}".format(detail_indent, cell_display))
   
    if src_info:
        print("{0}Source: {1}".format(detail_indent, src_info))
   
    if connected_net:
        if is_literal:
            if literal_value:
                print("{0}Drives: {1} = {2} (CONSTANT)".format(detail_indent, connected_net, literal_value))
            else:
                print("{0}Drives: {1} (CONSTANT)".format(detail_indent, connected_net))
        else:
            print("{0}Drives: {1}".format(detail_indent, connected_net))
   
    # Recursively print sub-drivers
    sub_drivers = info.get('sub_drivers', [])
    if sub_drivers:
        print("{0}| Driven by:".format(detail_indent))
        for sub in sub_drivers:
            print_driver_tree(sub, indent + 2, "", visited)
    else:
        if cell_type == 'npiNlFlipFlopCell':
            print("{0}[REGISTER - trace stops here]".format(detail_indent))
        elif is_literal:
            print("{0}[CONSTANT - trace stops here]".format(detail_indent))


def print_driver_summary(all_drivers, sig_name):
    """Print a summary table of all unique drivers found."""
    print("\n" + "="*80)
    print("SUMMARY: All Unique Drivers Found")
    print("="*80)
   
    if not all_drivers:
        print("  (none found)")
        return
   
    # Group by cell type
    by_type = {}
    for key, info in all_drivers.items():
        cell_type = info.get('cell_type', 'Unknown').replace('npiNl', '').replace('Cell', '')
        if cell_type not in by_type:
            by_type[cell_type] = []
        by_type[cell_type].append(info)
   
    for cell_type, drivers in sorted(by_type.items()):
        print("\n{0} ({1} driver(s)):".format(cell_type, len(drivers)))
        for info in drivers[:5]:  # Show first 5
            src = info.get('src_info', 'no source info')
            print("  - {0}".format(src))
        if len(drivers) > 5:
            print("  ... and {0} more".format(len(drivers) - 5))


def collect_all_drivers_recursive(info, results, prefix=""):
    """Flatten driver tree into results list."""
    if not info:
        return
    key = "{0}{1}".format(prefix, info['pin_name'])
    if key not in results:
        results[key] = info
    for sub in info.get("sub_drivers", []):
        collect_all_drivers_recursive(sub, results, prefix)


def find_force_statements(sig_name, force_list):
    """
    Check if any force statement targets the given signal.
    sig_name can be full hierarchy; we check if force LHS matches or is prefix.
    """
    matching = []
    for force_entry in force_list:
        force_lhs = force_entry.get("lhs_name") or ""
        force_rhs = force_entry.get("rhs_str") or ""
        force_src = force_entry.get("src_info") or ""
        # Match: force targets this signal, or signal is part of forced bus/struct
        if force_lhs and (sig_name == force_lhs or
            force_lhs.startswith(sig_name + ".") or
            force_lhs.startswith(sig_name + "[") or
            sig_name.startswith(force_lhs + ".") or
            sig_name.startswith(force_lhs + "[")):
            matching.append({
                "lhs": force_lhs,
                "rhs": force_rhs,
                "src": force_src,
            })
    return matching


def cb_collect_force(hdl, force_list):
    """Callback to collect force statements during lang hierarchy traversal."""
    if hdl is None:
        return
    try:
        hdl_type = hdl.type() if hasattr(hdl, 'type') else ""
        if hdl_type == 'npiForce':
            cps = hdl.cps_obj if hasattr(hdl, 'cps_obj') else hdl
            lhs_hdl = lang_l0.handle(lang_l0.Lhs, cps) if cps else None
            rhs_hdl = lang_l0.handle(lang_l0.Rhs, cps) if cps else None
            # Try FullName first, then Decompile for expression string
            lhs_name = ""
            if lhs_hdl:
                lhs_name = lang_l0.get_str(lang_l0.FullName, lhs_hdl) or ""
                if not lhs_name:
                    lhs_name = lang_l0.get_str(lang_l0.Decompile, lhs_hdl) or ""
            rhs_str = ""
            if rhs_hdl:
                rhs_str = lang_l0.get_str(lang_l0.FullName, rhs_hdl) or ""
                if not rhs_str:
                    rhs_str = lang_l0.get_str(lang_l0.Decompile, rhs_hdl) or ""
            f = lang_l0.get_str(lang_l0.File, cps) if cps else ""
            ln = lang_l0.get(lang_l0.LineNo, cps) if cps else 0
            src_info = "{0}:{1}".format(f, ln) if f else ""
            force_list.append({
                "lhs_name": lhs_name,
                "rhs_str": rhs_str,
                "src_info": src_info,
            })
    except Exception:
        pass


def get_signal_drivers(sig_name, dbdir, verbose=False):
    """
    Main function: get all drivers for a signal.
    Returns (drivers_dict, force_matches, nets_traversed)
    """
    all_drivers = OrderedDict()
    force_statements = []
    nets_traversed = []

    # Get net handle - try get_actual_net first (handles bit-select, etc.)
    nl_net = nl.get_actual_net(sig_name)
    if nl_net is None:
        nl_net = nl.get_net(sig_name)
    if nl_net is None:
        return all_drivers, [], []

    # Get nets to traverse (whole net or bit-blast)
    net_list = get_nets_to_traverse(nl_net)
    if not net_list:
        net_list = [(nl_net, "")]

    visited_drivers = set()
    for net_hdl, bit_suffix in net_list:
        net_full = net_hdl.full_name() if hasattr(net_hdl, 'full_name') else sig_name + bit_suffix
        actual_names = net_hdl.actual_name_list() if hasattr(net_hdl, 'actual_name_list') else [net_full]
        nets_traversed.extend(actual_names)

        try:
            drv_list = net_hdl.driver_list()
        except Exception:
            drv_list = []

        for drv_pin in drv_list:
            info = get_driver_info(drv_pin, visited_drivers)
            if info:
                info["drives_net"] = actual_names[0] if actual_names else net_full
                info["bit_suffix"] = bit_suffix
                collect_all_drivers_recursive(info, all_drivers)
    return all_drivers, force_statements, nets_traversed


def main():
    parser = argparse.ArgumentParser(
        description="Get all possible drivers for a signal using NPI KDB"
    )
    parser.add_argument("-dbdir", type=str, required=True,
                        help="Design database directory (e.g., simv.daidir)")
    parser.add_argument("-sig", type=str, required=True,
                        help="Signal full hierarchical name")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Verbose output")
    parser.add_argument("-bits", action="store_true",
                        help="Traverse each bit of bus individually (default: yes for buses)")
    args, remaining = parser.parse_known_args()

    npi_argv = [sys.argv[0], "-dbdir", args.dbdir] + remaining
    if not npisys.init(npi_argv):
        print("Error: Fail to initialize NPI.")
        sys.exit(1)
    if not npisys.load_design(npi_argv):
        print("Error: Fail to load design.")
        npisys.end()
        sys.exit(1)

    sig_name = args.sig
    print("\n" + "="*60)
    print("Signal: {0}".format(sig_name))
    print("="*60 + "\n")

    # Collect force statements via lang hierarchy traversal
    force_list = []
    try:
        lang.hier_tree_trv_register_cb('npiForce', cb_collect_force, force_list)
        lang.hier_tree_trv()
        lang.hier_tree_trv_reset_cb()
    except Exception as e:
        if args.verbose:
            print("Note: Force collection: {0}".format(e))

    # Get drivers
    all_drivers, _, nets_traversed = get_signal_drivers(sig_name, args.dbdir, args.verbose)

    # Check force on signal and its drivers
    force_on_sig = find_force_statements(sig_name, force_list)
    force_on_drivers = []
    for drv_key, drv_info in all_drivers.items():
        conn_net = drv_info.get("connected_net")
        if conn_net:
            matches = find_force_statements(conn_net, force_list)
            for m in matches:
                m["driver"] = drv_key
                force_on_drivers.append(m)

    # Print results
    print("\n" + "="*80)
    print("SIGNAL: {0}".format(sig_name))
    print("="*80)
   
    print("\nNets traversed ({0} bit(s)):".format(len(nets_traversed)))
    for n in nets_traversed[:10]:  # Show first 10
        print("  - {0}".format(n))
    if len(nets_traversed) > 10:
        print("  ... and {0} more".format(len(nets_traversed) - 10))
    print()

    print("\n" + "="*80)
    print("DRIVER CHAIN (hierarchical view)")
    print("="*80)
    print("Shows: Signal -> Immediate Drivers -> What Drives Them -> ...")
    print()
   
    if not all_drivers:
        print("  (no drivers found)")
    else:
        # Collect top-level drivers per net
        # We need to re-traverse to get the original driver structure
        top_level_drivers = []
        for net in nets_traversed[:10]:  # Show first 10 bits
            # Get drivers for this specific net
            net_drivers = []
            for key, info in all_drivers.items():
                if info.get('drives_net') == net:
                    net_drivers.append(info)
           
            if net_drivers:
                print("\n[Net: {0}]".format(net))
                if len(net_drivers) > 1:
                    print("  *** MULTIPLE DRIVERS DETECTED ({0}) ***".format(len(net_drivers)))
               
                for i, driver_info in enumerate(net_drivers, 1):
                    if len(net_drivers) > 1:
                        print()
                    print_driver_tree(driver_info, indent=0, driver_num=i if len(net_drivers) > 1 else None)
       
        if len(nets_traversed) > 10:
            print("\n... ({0} more bits not shown - they follow similar pattern)".format(len(nets_traversed) - 10))
   
    # Print summary
    print_driver_summary(all_drivers, sig_name)

    print("\n" + "="*80)
    print("FORCE STATEMENTS")
    print("="*80)
    if args.verbose and force_list:
        print("  (Collected {0} force stmt(s) in design)".format(len(force_list)))
        for i, f in enumerate(force_list):
            print("    [{0}] LHS={1} RHS={2} @ {3}".format(i, f.get('lhs_name'), f.get('rhs_str'), f.get('src_info')))
    if force_on_sig:
        for f in force_on_sig:
            print("  [Signal] force {0} = {1}  ({2})".format(f['lhs'], f['rhs'], f['src']))
    if force_on_drivers:
        for f in force_on_drivers:
            print("  [Driver {0}] force {1} = {2}  ({3})".format(f.get('driver',''), f['lhs'], f['rhs'], f['src']))
    if not force_on_sig and not force_on_drivers:
        print("  No force statements affect this signal or its drivers.")
    # If design has force stmts but we couldn't match LHS, inform user
    if force_list and not force_on_sig and not force_on_drivers:
        print("\n  Note: Design contains {0} force statement(s) - verify manually:".format(len(force_list)))
        for f in force_list[:5]:
            print("    - {0}".format(f.get('src_info', '')))
        if len(force_list) > 5:
            print("    ... and {0} more".format(len(force_list) - 5))
   
    print("\n" + "="*80)
    print("Done. Use -v for verbose output with all nets.")
    print("="*80 + "\n")

    npisys.end()


if __name__ == "__main__":
    main()
