#!/usr/bin/env bash
# Update synopsys_sim.setup files to point to correct UVM library version
# Usage: ./update_uvm_libs.sh <version>
#   version: W-2024.09 or X-2025.06

VERSION="${1}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Validate version argument
if [[ -z "${VERSION}" ]]; then
    echo "ERROR: Version argument required"
    echo "Usage: $0 <W-2024.09|X-2025.06>"
    exit 1
fi

# Normalize version format
case "${VERSION}" in
    W-2024.09|2024.09|W-2024.09-SP*|2024)
        VCS_VER="W-2024.09"
        ;;
    X-2025.06|2025.06|X-2025.06-SP*|2025)
        VCS_VER="X-2025.06"
        ;;
    *)
        echo "ERROR: Unknown version '${VERSION}'"
        echo "Supported: W-2024.09, X-2025.06"
        exit 1
        ;;
esac

echo "========================================================================"
echo "Updating UVM library paths to ${VCS_VER}"
echo "========================================================================"

# Define synopsys_sim.setup files to update (from Quip)
declare -A SETUP_FILES=(
    ["${REPO_ROOT}/blocks/c_die_top/verif/tb/synopsys_sim.setup"]="die_top"
    ["${REPO_ROOT}/blocks/dma/verif/tb/synopsys_sim.setup"]="skip"
    ["${REPO_ROOT}/blocks/h_die_top/verif/tb/synopsys_sim.setup"]="die_top"
    ["${REPO_ROOT}/blocks/io_die_top/verif/tb/synopsys_sim.setup"]="die_top"
    ["${REPO_ROOT}/blocks/maverick_top/verif/tb/synopsys_sim.setup"]="die_top"
    ["${REPO_ROOT}/blocks/pcie/pcie_new/chip_top_compile/synopsys_sim.setup"]="pcie_tb"
    ["${REPO_ROOT}/blocks/pcie/pcie_new/local_compile/synopsys_sim.setup"]="pcie_tb"
    ["${REPO_ROOT}/blocks/pcie/pcie_new/scripts/pcie_sys_compile/synopsys_sim.setup"]="pcie_tb"
    ["${REPO_ROOT}/blocks/pcie/pcie_new/scripts/synopsys_sim.setup"]="pcie_tb"
    ["${REPO_ROOT}/blocks/pcie/scripts/il_qual/synopsys_sim.setup"]="skip"
    ["${REPO_ROOT}/blocks/pcie/verif/tb/synopsys_sim.setup"]="pcie_tb"
    ["${REPO_ROOT}/blocks/soc_dfx/verif/tb/synopsys_sim.setup"]="soc_dfx"
    ["${REPO_ROOT}/blocks/ucie/rtl/d2d/rtl/phy/scripts/synopsys_sim.setup"]="skip"
    ["${REPO_ROOT}/blocks/ucie/rtl/d2d/scripts/synopsys_sim.setup"]="skip"
    ["${REPO_ROOT}/blocks/ucie/verif/tb/synopsys_sim.setup"]="ucie_tb"
    ["${REPO_ROOT}/blocks/vip_axi/verif/tb/synopsys_sim.setup"]="pcie_tb"
)

updated_count=0
skipped_count=0
error_count=0

for setup_file in "${!SETUP_FILES[@]}"; do
    uvm_type="${SETUP_FILES[$setup_file]}"
    
    # Skip DMA (no UVM lib needed)
    if [[ "${uvm_type}" == "skip" ]]; then
        echo "[SKIP] ${setup_file#${REPO_ROOT}/} (no UVM lib required)"
        ((skipped_count++))
        continue
    fi
    
    # Check if file exists
    if [[ ! -f "${setup_file}" ]]; then
        echo "[WARN] ${setup_file#${REPO_ROOT}/} not found"
        ((error_count++))
        continue
    fi
    
    # Determine new UVM lib path
    if [[ "${uvm_type}" == "ucie_tb" ]]; then
        new_path="/proj/trench/maverick_dv/uvm_lib/${VCS_VER}/ucie_tb/drop_synopsys_0.30a_pre1_a2x64_s2x16_PHY_SP1"
    elif [[ "${uvm_type}" == "soc_dfx" ]]; then
        new_path="/proj/trench/mariana_dv/soc_tb/${VCS_VER}/uvm_lib"
    else
        new_path="/proj/trench/maverick_dv/uvm_lib/${VCS_VER}/${uvm_type}/uvm_lib"
    fi
    
    # Backup original file
    if [[ ! -f "${setup_file}.bak" ]]; then
        cp "${setup_file}" "${setup_file}.bak"
    fi
    
    # Update the uvm_lib line
    if grep -q "^uvm_lib" "${setup_file}" 2>/dev/null; then
        old_path=$(grep "^uvm_lib" "${setup_file}" | awk '{print $3}')
        sed -i "s|^uvm_lib.*|uvm_lib : ${new_path}|" "${setup_file}"
        echo "[UPDATE] ${setup_file#${REPO_ROOT}/}"
        echo "  OLD: ${old_path}"
        echo "  NEW: ${new_path}"
        ((updated_count++))
    else
        echo "[WARN] ${setup_file#${REPO_ROOT}/} has no uvm_lib line (skipping)"
        ((error_count++))
    fi
done

echo ""
echo "========================================================================"
echo "Summary:"
echo "  Updated: ${updated_count}"
echo "  Skipped: ${skipped_count}"
echo "  Warnings: ${error_count}"
echo "========================================================================"
echo ""
echo "Backup files saved as *.bak"
echo "To restore: for f in \$(find ${REPO_ROOT}/blocks -name 'synopsys_sim.setup.bak'); do mv \$f \${f%.bak}; done"

# Exit with success if at least some files were updated
if [[ ${updated_count} -gt 0 ]]; then
    exit 0
else
    echo "ERROR: No files were updated successfully"
    exit 1
fi
