#!/bin/bash
export DISPLAY=$(hostname):1
xhost +

THEMES=(
  '#282A36 #F8F8F2 Dracula'
  '#002B36 #839496 Solarized-Dark'
  '#FDF6E3 #657B83 Solarized-Light'
  '#1D1F21 #C5C8C6 Tomorrow-Night'
  '#0C0C0C #CCCCCC Monokai'
  '#2E3440 #D8DEE9 Nord'
  '#1B2B34 #D8DEE9 Ocean'
  '#263238 #ECEFF1 Material'
  '#1E1E2E #CDD6F4 Catppuccin'
  '#24283B #C0CAF5 TokyoNight'
  '#292D3E #A6ACCD Palenight'
  '#011627 #D6DEEB NightOwl'
  '#1A1B26 #A9B1D6 Storm'
  '#161821 #C6C8D1 Iceberg'
  '#2B2D3A #D4D4D4 Ayu-Dark'
  '#FAFAFA #575F66 Ayu-Light'
  '#3B4252 #ECEFF4 Frost'
  '#1F2430 #CBCCC6 Ayu-Mirage'
  '#0D1117 #C9D1D9 GitHub-Dark'
  '#FFFFFF #24292F GitHub-Light'
)

COUNTER_FILE=~/.xterm_theme_counter
COUNT=$(cat "$COUNTER_FILE" 2>/dev/null || echo 0)
IDX=$((COUNT % ${#THEMES[@]}))
echo $(( COUNT + 1 )) > "$COUNTER_FILE"

read -r BG FG NAME <<< "${THEMES[$IDX]}"

sbatch -t 1-0 -c 8 --mem 64G -p verif_ae sbatch_wrap.sh xterm -T "x8 [$NAME]" -geometry 140x50 -fa 'DejaVu Sans Mono:size=12' -bg "$BG" -fg "$FG" -sl 10000
