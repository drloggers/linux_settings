#!/bin/csh
# CSH equivalent of setup_2025.06
# Usage: source ~/scripts/setup_2025.06.csh [-update_uvm]

set setvcs = X-2025.06-SP2
set update_uvm = false

if ( "$1" == "-update_uvm" ) then
    set update_uvm = true
endif

sed -i 's/^tools_ver=.*/tools_ver=vcs-qual/' $SOC_ROOT/.config
setenv VERDI_VER_OVERD $setvcs
setenv VCS_VER_OVERD $setvcs
module load mla_tools/vcs-qual
module load synopsys/vcs/$setvcs
module load synopsys/verdi/$setvcs

# Add VCS/VERDI version info to brazil_setup.bash if not already present
grep -q 'VCS_HOME = $VCS_HOME' $SOC_ROOT/common/verif/bin/brazil_setup.bash >& /dev/null
if ( $status != 0 ) then
    echo 'echo "=============================================="' >> $SOC_ROOT/common/verif/bin/brazil_setup.bash
    echo 'echo "VCS_HOME = $VCS_HOME"' >> $SOC_ROOT/common/verif/bin/brazil_setup.bash
    echo 'echo "VERDI_HOME = $VERDI_HOME"' >> $SOC_ROOT/common/verif/bin/brazil_setup.bash
    echo 'echo "=============================================="' >> $SOC_ROOT/common/verif/bin/brazil_setup.bash
    echo 'echo' >> $SOC_ROOT/common/verif/bin/brazil_setup.bash
    echo "Added VCS/VERDI version info to brazil_setup.bash"
else
    echo "VCS/VERDI version info already exists in brazil_setup.bash (skipped)"
endif

if ( "$update_uvm" == "true" ) then
    echo ""
    ~/scripts/update_uvm_libs.sh X-2025.06
endif
