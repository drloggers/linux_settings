#!/bin/sh

emacs "$@" &
