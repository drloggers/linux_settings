#!/bin/bash
# Installs color themes as GNOME Terminal profiles
# After running, go to: Terminal -> Change Profile to switch themes
#
# Usage:
#   bash install_gnome_profiles.sh            # install all
#   bash install_gnome_profiles.sh --remove   # remove all
#   bash install_gnome_profiles.sh --list     # list installed theme profiles

PREFIX="QT"  # prefix for all managed profiles
DCONF_BASE="/org/gnome/terminal/legacy/profiles:"

create_profile() {
    local name="$1" bg="$2" fg="$3" cursor="$4"
    shift 4
    local palette="$*"

    local uuid
    uuid=$(uuidgen)
    local path="${DCONF_BASE}/:${uuid}/"

    local existing
    existing=$(dconf read ${DCONF_BASE}/list 2>/dev/null)
    if [[ -z "$existing" || "$existing" == "@as []" ]]; then
        dconf write ${DCONF_BASE}/list "['${uuid}']"
    else
        local new_list="${existing%]*}, '${uuid}']"
        dconf write ${DCONF_BASE}/list "$new_list"
    fi

    dconf write "${path}visible-name" "'${PREFIX} ${name}'"
    dconf write "${path}use-theme-colors" "false"
    dconf write "${path}background-color" "'${bg}'"
    dconf write "${path}foreground-color" "'${fg}'"
    dconf write "${path}cursor-background-color" "'${cursor}'"
    dconf write "${path}cursor-colors-set" "true"
    dconf write "${path}palette" "${palette}"
    dconf write "${path}use-system-font" "false"
    dconf write "${path}font" "'DejaVu Sans Mono 12'"
    dconf write "${path}default-size-columns" "140"
    dconf write "${path}default-size-rows" "50"
    dconf write "${path}bold-is-bright" "true"

    echo "  ✔ ${PREFIX} ${name}"
}

remove_profiles() {
    echo "Removing ${PREFIX} profiles..."
    local list
    list=$(dconf read ${DCONF_BASE}/list 2>/dev/null)
    [[ -z "$list" ]] && echo "No profiles found." && return

    local uuids
    uuids=$(echo "$list" | tr -d "[]' " | tr ',' '\n')

    local keep=()
    for uuid in $uuids; do
        local vname
        vname=$(dconf read "${DCONF_BASE}/:${uuid}/visible-name" 2>/dev/null)
        if [[ "$vname" == *"${PREFIX} "* ]]; then
            dconf reset -f "${DCONF_BASE}/:${uuid}/"
            echo "  Removed: $vname"
        else
            keep+=("'${uuid}'")
        fi
    done

    local new_list
    new_list=$(IFS=,; echo "[${keep[*]}]")
    new_list=$(echo "$new_list" | sed 's/,/, /g')
    dconf write ${DCONF_BASE}/list "$new_list"
    echo "Done."
}

list_profiles() {
    local list
    list=$(dconf read ${DCONF_BASE}/list 2>/dev/null)
    [[ -z "$list" ]] && echo "No profiles found." && return

    local uuids
    uuids=$(echo "$list" | tr -d "[]' " | tr ',' '\n')

    echo ""
    echo "  Installed ${PREFIX} profiles:"
    echo "  ────────────────────────────────"
    local count=0
    for uuid in $uuids; do
        local vname
        vname=$(dconf read "${DCONF_BASE}/:${uuid}/visible-name" 2>/dev/null | tr -d "'")
        if [[ "$vname" == "${PREFIX} "* ]]; then
            count=$((count + 1))
            echo "    ${count}. ${vname}"
        fi
    done
    [[ $count -eq 0 ]] && echo "    (none)"
    echo ""
}

install_profiles() {
    echo ""
    echo "Installing GNOME Terminal profiles..."
    echo "══════════════════════════════════════════════"

    # ── Pastel Themes ──────────────────────────────────
    echo ""
    echo "  Pastel:"
    echo "  ───────"

    create_profile "Pastel Rose" \
        "#2b1b2e" "#f2d7d5" "#f5b7b1" \
        "['#3b2636', '#e6a8a1', '#a8d8b9', '#f7dc9e', '#a9cce3', '#d7bde2', '#a3e4d7', '#f2d7d5', '#5b4660', '#f5b7b1', '#c8f8d9', '#ffecae', '#c9ecf3', '#e7cdf2', '#c3f4e7', '#fff7f5']"

    create_profile "Pastel Mint" \
        "#1a2b2b" "#d5f5e3" "#abebc6" \
        "['#1e3333', '#f1948a', '#abebc6', '#f9e79f', '#aed6f1', '#d2b4de', '#a3e4d7', '#d5f5e3', '#2e5353', '#f5b4ae', '#cbffe6', '#fff9bf', '#cef6ff', '#e2d4ee', '#c3f4e7', '#f5fff3']"

    create_profile "Pastel Lavender" \
        "#1e1b2e" "#e8daef" "#d2b4de" \
        "['#2c2440', '#f1948a', '#a9dfbf', '#f9e79f', '#a9cce3', '#d7bde2', '#a2d9ce', '#e8daef', '#4c4470', '#f5b4ae', '#c9ffdf', '#fff9bf', '#c9ecf3', '#e7cdf2', '#c2f9ee', '#f8faff']"

    create_profile "Pastel Sky" \
        "#1b2631" "#d6eaf8" "#aed6f1" \
        "['#1f3044', '#f5b7b1', '#a9dfbf', '#fad7a0', '#aed6f1', '#d2b4de', '#a3e4d7', '#d6eaf8', '#2f5074', '#f5d7d1', '#c9ffdf', '#fff7c0', '#cef6ff', '#e2d4ee', '#c3f4e7', '#f6faff']"

    create_profile "Pastel Peach" \
        "#2c1f1a" "#fdebd0" "#fad7a0" \
        "['#3b2a1f', '#f1948a', '#a9dfbf', '#fad7a0', '#aed6f1', '#d7bde2', '#a3e4d7', '#fdebd0', '#5b4a3f', '#f5b4ae', '#c9ffdf', '#fff7c0', '#cef6ff', '#e7cdf2', '#c3f4e7', '#fffbf0']"

    create_profile "Pastel Lemon" \
        "#2a2a1a" "#fcf3cf" "#f9e79f" \
        "['#33331f', '#f5b7b1', '#abebc6', '#f9e79f', '#aed6f1', '#d2b4de', '#a3e4d7', '#fcf3cf', '#53533f', '#f5d7d1', '#cbffe6', '#fff9bf', '#cef6ff', '#e2d4ee', '#c3f4e7', '#fffff0']"

    # ── Classic Dark Themes ────────────────────────────
    echo ""
    echo "  Classic Dark:"
    echo "  ─────────────"

    create_profile "Dracula" \
        "#282a36" "#f8f8f2" "#f8f8f2" \
        "['#21222c', '#ff5555', '#50fa7b', '#f1fa8c', '#bd93f9', '#ff79c6', '#8be9fd', '#f8f8f2', '#6272a4', '#ff6e6e', '#69ff94', '#ffffa5', '#d6acff', '#ff92df', '#a4ffff', '#ffffff']"

    create_profile "Monokai" \
        "#272822" "#f8f8f2" "#f8f8f0" \
        "['#272822', '#f92672', '#a6e22e', '#f4bf75', '#66d9ef', '#ae81ff', '#a1efe4', '#f8f8f2', '#75715e', '#f92672', '#a6e22e', '#f4bf75', '#66d9ef', '#ae81ff', '#a1efe4', '#f9f8f5']"

    create_profile "One Dark" \
        "#282c34" "#abb2bf" "#528bff" \
        "['#282c34', '#e06c75', '#98c379', '#e5c07b', '#61afef', '#c678dd', '#56b6c2', '#abb2bf', '#545862', '#e06c75', '#98c379', '#e5c07b', '#61afef', '#c678dd', '#56b6c2', '#c8ccd4']"

    create_profile "Tokyo Night" \
        "#1a1b26" "#c0caf5" "#c0caf5" \
        "['#15161e', '#f7768e', '#9ece6a', '#e0af68', '#7aa2f7', '#bb9af7', '#7dcfff', '#a9b1d6', '#414868', '#f7768e', '#9ece6a', '#e0af68', '#7aa2f7', '#bb9af7', '#7dcfff', '#c0caf5']"

    create_profile "Catppuccin Mocha" \
        "#1e1e2e" "#cdd6f4" "#f5e0dc" \
        "['#45475a', '#f38ba8', '#a6e3a1', '#f9e2af', '#89b4fa', '#f5c2e7', '#94e2d5', '#bac2de', '#585b70', '#f38ba8', '#a6e3a1', '#f9e2af', '#89b4fa', '#f5c2e7', '#94e2d5', '#a6adc8']"

    # ── Nord / Cool Themes ─────────────────────────────
    echo ""
    echo "  Cool:"
    echo "  ─────"

    create_profile "Nord" \
        "#2e3440" "#d8dee9" "#d8dee9" \
        "['#3b4252', '#bf616a', '#a3be8c', '#ebcb8b', '#81a1c1', '#b48ead', '#88c0d0', '#e5e9f0', '#4c566a', '#bf616a', '#a3be8c', '#ebcb8b', '#81a1c1', '#b48ead', '#8fbcbb', '#eceff4']"

    create_profile "Gruvbox Dark" \
        "#282828" "#ebdbb2" "#ebdbb2" \
        "['#282828', '#cc241d', '#98971a', '#d79921', '#458588', '#b16286', '#689d6a', '#a89984', '#928374', '#fb4934', '#b8bb26', '#fabd2f', '#83a598', '#d3869b', '#8ec07c', '#ebdbb2']"

    # ── Solarized ──────────────────────────────────────
    echo ""
    echo "  Solarized:"
    echo "  ──────────"

    create_profile "Solarized Dark" \
        "#002b36" "#839496" "#839496" \
        "['#073642', '#dc322f', '#859900', '#b58900', '#268bd2', '#d33682', '#2aa198', '#eee8d5', '#002b36', '#cb4b16', '#586e75', '#657b83', '#839496', '#6c71c4', '#93a1a1', '#fdf6e3']"

    create_profile "Solarized Light" \
        "#fdf6e3" "#657b83" "#586e75" \
        "['#073642', '#dc322f', '#859900', '#b58900', '#268bd2', '#d33682', '#2aa198', '#eee8d5', '#002b36', '#cb4b16', '#586e75', '#657b83', '#839496', '#6c71c4', '#93a1a1', '#fdf6e3']"

    # ── Retro / Fun ────────────────────────────────────
    echo ""
    echo "  Retro / Fun:"
    echo "  ────────────"

    create_profile "Cyberpunk" \
        "#0d0221" "#f2e6ff" "#ff2079" \
        "['#1a0a2e', '#ff2079', '#00ff9f', '#fed136', '#04d9ff', '#f222ff', '#00ffff', '#f2e6ff', '#3b1e5f', '#ff4da6', '#66ffcc', '#ffe066', '#66e5ff', '#f566ff', '#66ffff', '#ffffff']"

    create_profile "Synthwave" \
        "#2b213a" "#f0e4fc" "#ff7edb" \
        "['#3b2d56', '#fe4450', '#72f1b8', '#fede5d', '#03edf9', '#ff7edb', '#03edf9', '#f0e4fc', '#544a6e', '#fe6e7a', '#9ff8d0', '#feef7d', '#5af3ff', '#ff9fe5', '#5af3ff', '#ffffff']"

    create_profile "Matrix" \
        "#0d1117" "#00ff41" "#00ff41" \
        "['#0d1117', '#ff0000', '#00ff41', '#ffff00', '#0099ff', '#ff00ff', '#00ffff', '#d0d0d0', '#1a2332', '#ff3333', '#33ff66', '#ffff66', '#33aaff', '#ff33ff', '#33ffff', '#ffffff']"

    echo ""
    echo "══════════════════════════════════════════════"
    echo "Done! Profiles are now available in:"
    echo "  Terminal -> Change Profile"
    echo ""
    echo "Commands:"
    echo "  bash $0 --list     # list installed profiles"
    echo "  bash $0 --remove   # remove all ${PREFIX} profiles"
    echo ""
}

# ── Main ──
case "$1" in
    --remove) remove_profiles ;;
    --list)   list_profiles ;;
    *)        install_profiles ;;
esac
