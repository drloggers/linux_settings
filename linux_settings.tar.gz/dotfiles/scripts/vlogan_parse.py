#!/usr/bin/env python3
"""
Fast parser for vlogan/vcs logfiles to extract unique file list.
Processes line-by-line for memory efficiency and optimized for speed.
"""

import re
import sys
import argparse
from pathlib import Path

# Pre-compiled regex patterns for maximum performance
# Using non-greedy match with lookahead for better performance
PATTERN_DESIGN_FILE = re.compile(r"Parsing design file '([^']+)'")
PATTERN_INCLUDED_FILE = re.compile(r"Parsing included file '([^']+)'")
PATTERN_BACK_TO_FILE = re.compile(r"Back to file '([^']+)'")


def parse_logfile(logfile_path, output_file=None, verbose=False):
    """
    Parse vlogan/vcs logfile and extract unique file list.
   
    Args:
        logfile_path: Path to the logfile
        output_file: Optional output file path (default: <logfile>.filelist)
        verbose: Print progress messages
   
    Returns:
        Set of unique file paths
    """
    logfile_path = Path(logfile_path)
   
    if not logfile_path.exists():
        print(f"Error: Logfile not found: {logfile_path}", file=sys.stderr)
        sys.exit(1)
   
    if verbose:
        print(f"Parsing logfile: {logfile_path}")
   
    # Use set for O(1) deduplication
    unique_files = set()
   
    # Process line by line for memory efficiency
    try:
        with open(logfile_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                # Strip once for efficiency
                line_stripped = line.strip()
               
                # Check for design files (most common pattern) - short-circuit on match
                match = PATTERN_DESIGN_FILE.search(line_stripped)
                if match:
                    unique_files.add(match.group(1))
                    continue
               
                # Check for included files
                match = PATTERN_INCLUDED_FILE.search(line_stripped)
                if match:
                    unique_files.add(match.group(1))
                    continue
               
                # Check for "Back to file" pattern
                match = PATTERN_BACK_TO_FILE.search(line_stripped)
                if match:
                    unique_files.add(match.group(1))
   
    except IOError as e:
        print(f"Error reading logfile: {e}", file=sys.stderr)
        sys.exit(1)
   
    if verbose:
        print(f"Found {len(unique_files)} unique files")
   
    # Determine output file
    if output_file is None:
        output_file = logfile_path.with_suffix('.filelist')
    else:
        output_file = Path(output_file)
   
    # Write unique files to output (sorted for consistency)
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            # Write sorted list for consistent output
            for filepath in sorted(unique_files):
                f.write(f"{filepath}\n")
       
        if verbose:
            print(f"Output written to: {output_file}")
            print(f"Total unique files: {len(unique_files)}")
   
    except IOError as e:
        print(f"Error writing output file: {e}", file=sys.stderr)
        sys.exit(1)
   
    return unique_files


def main():
    parser = argparse.ArgumentParser(
        description='Parse vlogan/vcs logfile and extract unique file list',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s -file compile.log
  %(prog)s -file vlogan.log -output filelist.f
  %(prog)s -file vcs.log -verbose
        """
    )
   
    parser.add_argument(
        '-file', '--logfile',
        required=True,
        help='Path to vlogan/vcs logfile'
    )
   
    parser.add_argument(
        '-output', '-o',
        default=None,
        help='Output file path (default: <logfile>.filelist)'
    )
   
    parser.add_argument(
        '-verbose', '-v',
        action='store_true',
        help='Print verbose progress messages'
    )
   
    args = parser.parse_args()
   
    # Parse the logfile
    unique_files = parse_logfile(
        args.logfile,
        output_file=args.output,
        verbose=args.verbose
    )
   
    # Exit successfully
    sys.exit(0)


if __name__ == '__main__':
    main()
