#!/bin/bash
# sim_perf_report.sh
# Finds all sim.log files across WORK folders and generates a side-by-side
# comparison CSV for easy cross-loop comparison.
#
# Modes:
#   1) Extract:  sim_perf_report.sh <sim_dir> [output_dir]
#   2) Compare:  sim_perf_report.sh --compare <csv_A> <csv_B> [output_csv]
#      Produces side-by-side comparison with delta (diff & %) columns
#
# Optimizations:
#   - Shell glob (handles colons in dir names where find fails)
#   - tail -200 per file (stats are at end, skips GB of log data)
#   - All tails concatenated with markers, parsed by single awk
#   - No per-file bash/awk spawns

GREEN='\033[0;32m'
CYAN='\033[0;36m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BOLD='\033[1m'
RESET='\033[0m'

# ══════════════════════════════════════════════════════════════
# Compare mode
# ══════════════════════════════════════════════════════════════
if [[ "$1" == "--compare" ]]; then
    CSV_A="${2:?Usage: $0 --compare <csv_A> <csv_B> [output_csv]}"
    CSV_B="${3:?Usage: $0 --compare <csv_A> <csv_B> [output_csv]}"
    OUT_CSV="${4:-comparison_$(date +%Y%m%d_%H%M%S).csv}"

    [[ ! -f "$CSV_A" ]] && echo -e "${RED}File not found: $CSV_A${RESET}" && exit 1
    [[ ! -f "$CSV_B" ]] && echo -e "${RED}File not found: $CSV_B${RESET}" && exit 1

    LABEL_A=$(basename "$CSV_A" .csv)
    LABEL_B=$(basename "$CSV_B" .csv)

    echo -e "\n${BOLD}================================================================${RESET}"
    echo -e "${BOLD}  CSV Comparison Report${RESET}"
    echo -e "${BOLD}================================================================${RESET}"
    echo -e "  A : ${CYAN}${CSV_A}${RESET}"
    echo -e "  B : ${CYAN}${CSV_B}${RESET}"
    echo -e "${BOLD}================================================================${RESET}\n"

    awk -F',' '
    function abs(v) { return v < 0 ? -v : v }
    function pct(a, b) {
        if (a == "" || b == "" || a+0 == 0) return ""
        return sprintf("%.1f%%", ((b - a) / a) * 100)
    }
    function delta(a, b) {
        if (a == "" || b == "") return ""
        return sprintf("%.1f", b - a)
    }

    # Read CSV_A (file 1)
    FNR == NR && FNR == 1 { next }  # skip header
    FNR == NR {
        test = $1
        a_ec[test] = $2; a_cc[test] = $3
        a_es[test] = $4; a_cs[test] = $5
        a_mc[test] = $6; a_ms[test] = $7
        a_st[test] = $8
        tests[test] = 1
        next
    }

    # Read CSV_B (file 2)
    FNR == 1 { next }  # skip header
    {
        test = $1
        b_ec[test] = $2; b_cc[test] = $3
        b_es[test] = $4; b_cs[test] = $5
        b_mc[test] = $6; b_ms[test] = $7
        b_st[test] = $8
        tests[test] = 1
    }

    END {
        # Header row 1: group labels
        printf "Test_Name"
        printf ",--- %s ---,,,,,,", label_a
        printf ",--- %s ---,,,,,,", label_b
        printf ",--- Delta (B-A) ---,,,,,,"
        printf ",--- Delta %% ---,,,,,"
        printf "\n"

        # Header row 2: columns
        printf "Test_Name"
        for (i = 1; i <= 2; i++) {
            printf ",Elapsed_Compile,Compile_CPU,Elapsed_Sim,Sim_CPU,Compile_Mem,Sim_Mem,Status"
        }
        printf ",D_Elapsed_Compile,D_Compile_CPU,D_Elapsed_Sim,D_Sim_CPU,D_Compile_Mem,D_Sim_Mem"
        printf ",%%_Elapsed_Compile,%%_Compile_CPU,%%_Elapsed_Sim,%%_Sim_CPU,%%_Compile_Mem"
        printf "\n"

        # Sort tests
        n = asorti(tests, sorted)
        for (i = 1; i <= n; i++) {
            t = sorted[i]
            printf "%s", t

            # A values
            printf ",%s,%s,%s,%s,%s,%s,%s", a_ec[t], a_cc[t], a_es[t], a_cs[t], a_mc[t], a_ms[t], a_st[t]

            # B values
            printf ",%s,%s,%s,%s,%s,%s,%s", b_ec[t], b_cc[t], b_es[t], b_cs[t], b_mc[t], b_ms[t], b_st[t]

            # Delta (B - A)
            printf ",%s,%s,%s,%s,%s,%s", \
                delta(a_ec[t], b_ec[t]), delta(a_cc[t], b_cc[t]), \
                delta(a_es[t], b_es[t]), delta(a_cs[t], b_cs[t]), \
                delta(a_mc[t], b_mc[t]), delta(a_ms[t], b_ms[t])

            # Delta %
            printf ",%s,%s,%s,%s,%s", \
                pct(a_ec[t], b_ec[t]), pct(a_cc[t], b_cc[t]), \
                pct(a_es[t], b_es[t]), pct(a_cs[t], b_cs[t]), \
                pct(a_mc[t], b_mc[t])

            printf "\n"
        }
    }
    ' "$CSV_A" label_a="$LABEL_A" label_b="$LABEL_B" "$CSV_B" > "$OUT_CSV"

    TOTAL=$(awk 'END{print NR-2}' "$OUT_CSV")

    # Print per-test comparison to terminal
    echo -e "${BOLD}Per-test comparison ($TOTAL tests):${RESET}"
    echo -e "  A = $LABEL_A"
    echo -e "  B = $LABEL_B\n"

    awk -F',' -v green="$GREEN" -v red="$RED" -v yellow="$YELLOW" -v bold="$BOLD" -v nc="$RESET" '
    function color_pct(val) {
        if (val == "") return sprintf("%8s", "-")
        gsub(/%/, "", val)
        v = val + 0
        if (v < -5) return sprintf("%s%+7.1f%%%s", green, v, nc)
        if (v > 5)  return sprintf("%s%+7.1f%%%s", red, v, nc)
        return sprintf("%+7.1f%%", v)
    }
    NR <= 2 { next }
    NR == 3 {
        printf "  %-45s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s\n", \
            "Test", "A_Compile", "B_Compile", "Diff%", "A_Sim", "B_Sim", "Diff%", "A_SimCPU", "B_SimCPU", "Diff%", "Status"
        printf "  %-45s %10s %10s %10s %10s %10s %10s %10s %10s %10s %10s\n", \
            "---------------------------------------------", "----------", "----------", "----------", "----------", "----------", "----------", "----------", "----------", "----------", "----------"
    }
    {
        tname = $1
        if (length(tname) > 45) tname = substr(tname, 1, 42) "..."

        a_ec = $2;  b_ec = $9;   pct_ec = $22
        a_es = $4;  b_es = $11;  pct_es = $24
        a_cs = $5;  b_cs = $12;  pct_cs = $25
        st_a = $8;  st_b = $15

        st = st_a
        if (st_a != st_b) st = st_a "/" st_b

        printf "  %-45s %10s %10s %s %10s %10s %s %10s %10s %s %10s\n", \
            tname, \
            (a_ec != "" ? a_ec "s" : "-"), (b_ec != "" ? b_ec "s" : "-"), color_pct(pct_ec), \
            (a_es != "" ? a_es "s" : "-"), (b_es != "" ? b_es "s" : "-"), color_pct(pct_es), \
            (a_cs != "" ? a_cs "s" : "-"), (b_cs != "" ? b_cs "s" : "-"), color_pct(pct_cs), \
            st
    }
    END {
        printf "\n"
    }
    ' "$OUT_CSV"

    echo ""
    echo -e "${BOLD}================================================================${RESET}"
    echo -e "  Output: ${CYAN}${OUT_CSV}${RESET}"
    echo -e "${BOLD}================================================================${RESET}\n"
    exit 0
fi

# ══════════════════════════════════════════════════════════════
# Extract mode (original behavior)
# ══════════════════════════════════════════════════════════════
SIM_DIR="${1:?Usage: $0 <sim_dir> [output_dir]}"
OUT_DIR="${2:-$(pwd)/perf_report_$(date +%Y%m%d_%H%M%S)}"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
BOLD='\033[1m'
RESET='\033[0m'

mkdir -p "$OUT_DIR"

echo -e "\n${BOLD}================================================================${RESET}"
echo -e "${BOLD}  Sim Performance Report Generator${RESET}"
echo -e "${BOLD}================================================================${RESET}"
echo -e "  Source : ${CYAN}${SIM_DIR}${RESET}"
echo -e "  Output : ${CYAN}${OUT_DIR}${RESET}"
echo -e "${BOLD}================================================================${RESET}\n"

# ── Step 1: Find all sim.log files ──
echo -e "${BOLD}[1/3] Finding sim.log files...${RESET}"

shopt -s nullglob
SIM_LOGS=("$SIM_DIR"/WORK_*/*/sim.log)
shopt -u nullglob

IFS=$'\n' SIM_LOGS=($(sort <<<"${SIM_LOGS[*]}")); unset IFS

TOTAL=${#SIM_LOGS[@]}
echo -e "  Found ${GREEN}${TOTAL}${RESET} sim.log files\n"

if [[ $TOTAL -eq 0 ]]; then
    echo "No sim.log files found. Exiting."
    rm -rf "$OUT_DIR"
    exit 1
fi

# ── Step 2: Tail all files into one stream with markers, parse with single awk ──
echo -e "${BOLD}[2/3] Extracting performance data...${RESET}"

RAW_DATA="$OUT_DIR/.raw_data.tmp"
COMBINED="$OUT_DIR/.combined.tmp"

# Build combined stream: marker line then tail of each file
# Marker format: @@MARKER@@folder@@testname@@
> "$COMBINED"
for simlog in "${SIM_LOGS[@]}"; do
    testdir=$(dirname "$simlog")
    testdir_name=$(basename "$testdir")
    folder_name=$(basename "$(dirname "$testdir")")
    test_name=$(echo "$testdir_name" | awk -F: '{print $2}')
    [[ -z "$test_name" ]] && test_name="$testdir_name"
    echo "@@MARKER@@${folder_name}@@${test_name}@@"
    tail -200 "$simlog" 2>/dev/null
done >> "$COMBINED"

echo -e "  Tailed ${GREEN}${TOTAL}${RESET} files"

# Single awk pass over the combined stream
awk '
/^@@MARKER@@/ {
    # Emit previous record
    if (folder != "") {
        st = "UNKNOWN"
        if (uf > 0) st = "FATAL(" uf ")"
        else if (ue > 0) st = "ERROR(" ue ")"
        else if (up > 0) st = "PASS"
        printf "%s,%s,%s,%s,%s,%s,%s,%s,%s\n", folder, tname, ec, cc, mc, es, cs, ms, st
    }
    # Parse marker: @@MARKER@@folder@@testname@@
    split($0, m, "@@")
    folder = m[3]; tname = m[4]
    ic = 0; is = 0
    ec = ""; cc = ""; mc = ""
    es = ""; cs = ""; ms = ""
    uf = 0; ue = 0; up = 0
    next
}
/Compilation Performance Summary/ { ic = 1; is = 0; next }
/Simulation Performance Summary/  { is = 1; ic = 0; next }
ic && /Elapsed/        { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); ec=a[2] }
ic && /CPU Time/       { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); cc=a[2] }
ic && /Virtual memory/ { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); mc=a[2]; ic=0 }
is && /Elapsed/        { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); es=a[2] }
is && /CPU Time/       { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); cs=a[2] }
is && /Virtual memory/ { split($0,a,":"); gsub(/[^0-9.]/,"",a[2]); ms=a[2]; is=0 }
/UVM_FATAL/                   { uf++ }
/UVM_ERROR/                   { ue++ }
/TEST PASSED/ || /UVM_PASSED/ { up++ }
END {
    if (folder != "") {
        st = "UNKNOWN"
        if (uf > 0) st = "FATAL(" uf ")"
        else if (ue > 0) st = "ERROR(" ue ")"
        else if (up > 0) st = "PASS"
        printf "%s,%s,%s,%s,%s,%s,%s,%s,%s\n", folder, tname, ec, cc, mc, es, cs, ms, st
    }
}
' "$COMBINED" > "$RAW_DATA"

rm -f "$COMBINED"

EXTRACTED=$(wc -l < "$RAW_DATA")
echo -e "  Extracted ${GREEN}${EXTRACTED}/${TOTAL}${RESET} results\n"

# ── Step 3: Build side-by-side comparison CSV ──
echo -e "${BOLD}[3/3] Building comparison CSV...${RESET}"

declare -A TEST_DATA ALL_TESTS FOLDERS_SEEN

while IFS=',' read -r folder tname ec cc mc es cs ms status; do
    FOLDERS_SEEN["$folder"]=1
    ALL_TESTS["$tname"]=1
    TEST_DATA["${folder}|${tname}"]="${ec},${cc},${es},${cs},${mc},${ms},${status}"
done < "$RAW_DATA"

IFS=$'\n' FOLDERS=($(sort <<<"${!FOLDERS_SEEN[*]}")); unset IFS
IFS=$'\n' SORTED_TESTS=($(sort <<<"${!ALL_TESTS[*]}")); unset IFS

FINAL_CSV="$OUT_DIR/comparison_report.csv"

# Header row 1: folder group labels
header1="Test_Name"
for folder in "${FOLDERS[@]}"; do
    short=$(echo "$folder" | sed 's/WORK_lustre_soc_//')
    header1="${header1},--- ${short} ---,,,,,,"
done

# Header row 2: metric columns
header2="Test_Name"
for folder in "${FOLDERS[@]}"; do
    header2="${header2},Elapsed_Compile,Compile_CPU,Elapsed_Sim,Sim_CPU,Compile_Mem,Sim_Mem,Status"
done

{
    echo "$header1"
    echo "$header2"
    for test in "${SORTED_TESTS[@]}"; do
        row="$test"
        for folder in "${FOLDERS[@]}"; do
            vals="${TEST_DATA[${folder}|${test}]}"
            if [[ -n "$vals" ]]; then
                row="${row},${vals}"
            else
                row="${row},,,,,,,"
            fi
        done
        echo "$row"
    done
} > "$FINAL_CSV"

# Per-folder CSVs
for folder in "${FOLDERS[@]}"; do
    per_csv="$OUT_DIR/${folder}_perf.csv"
    echo "Testname,Elapsed_Compile_Time,Compile_cputime,Elapsed_Sim_Time,Sim_cputime,Compile_Virtual_mem,Sim_Virtual_mem,Status" > "$per_csv"
    while IFS=',' read -r f tname ec cc mc es cs ms status; do
        [[ "$f" == "$folder" ]] && echo "${tname},${ec},${cc},${es},${cs},${mc},${ms},${status}" >> "$per_csv"
    done < "$RAW_DATA"
done

rm -f "$RAW_DATA"

TOTAL_TESTS=${#SORTED_TESTS[@]}
TOTAL_FOLDERS=${#FOLDERS[@]}

echo -e "  Tests  : ${GREEN}${TOTAL_TESTS}${RESET}"
echo -e "  Folders: ${GREEN}${TOTAL_FOLDERS}${RESET}"
echo ""
echo -e "${BOLD}================================================================${RESET}"
echo -e "${BOLD}  Output Files${RESET}"
echo -e "${BOLD}================================================================${RESET}"
echo -e "  ${CYAN}${FINAL_CSV}${RESET}"
echo -e "    -> Side-by-side: same test across all loops\n"
echo -e "  Individual per-loop reports:"
for folder in "${FOLDERS[@]}"; do
    echo -e "    ${CYAN}${OUT_DIR}/${folder}_perf.csv${RESET}"
done
echo -e "${BOLD}================================================================${RESET}\n"
