#!/usr/bin/env python3
"""
VCS Filelist Analyzer - Find actual files used in design vs parsed files
Efficiently compares NPI-extracted files with VCS compile log parsing
"""

import sys
import os
import re
import argparse
from pathlib import Path

# Import pynpi (optional, kept for future NPI-based extensions)
pynpi_lib_path = os.environ.get("VERDI_HOME", "") + "/share/NPI/python"
NPI_AVAILABLE = os.path.exists(pynpi_lib_path)

class FileListCollector:
    """Collect unique file paths efficiently"""
    
    def __init__(self):
        self.files = set()
    
    def add(self, filepath):
        """Add file with full path resolution"""
        if filepath:
            self.files.add(os.path.realpath(filepath))
    
    def get_sorted(self):
        """Return sorted list of files"""
        return sorted(self.files)


def extract_design_files_npi(dbdir):
    """Extract files used in elaborated design.
    - KDB flow (-kdb): uses debug_dump/src_files_verilog
    - Legacy flow: uses work.lib++/MapTbl (strings-parsed for absolute .v/.sv paths)
    For KDB flow, combines with NPI to filter out unelaborated modules.
    """
    src_files_path = os.path.join(dbdir, "debug_dump", "src_files_verilog")
    maptbl_path = os.path.join(dbdir, "work.lib++", "MapTbl")

    if os.path.exists(src_files_path):
        return _extract_kdb_flow(dbdir, src_files_path)
    elif os.path.exists(maptbl_path):
        return _extract_maptbl_flow(maptbl_path)
    else:
        print(f"Error: Neither {src_files_path} nor {maptbl_path} found.")
        print("Compile with -debug_access+all and optionally -kdb.")
        return []


def _extract_maptbl_flow(maptbl_path):
    """Extract source files from work.lib++/MapTbl (legacy VCS flow)"""
    import subprocess
    print(f"Extracting design files from: {maptbl_path}")
    file_re = re.compile(r'^/\S+\.(?:sv|v|vh|svh)$')
    collector = FileListCollector()
    out = subprocess.check_output(['strings', maptbl_path]).decode(errors='ignore')
    for line in out.splitlines():
        if file_re.match(line):
            collector.add(line)
    files = collector.get_sorted()
    print(f"Found {len(files)} unique files in design")
    return files


def _extract_kdb_flow(dbdir, src_files_path):
    """Extract files for KDB flow using NPI + src_files_verilog"""
    if not NPI_AVAILABLE:
        print("Error: VERDI_HOME not set. Cannot run NPI.")
        return []

    with open(src_files_path, 'r', errors='ignore') as f:
        compiled_files = [l.strip() for l in f if l.strip()]

    print(f"Extracting design files from: {dbdir}")

    sys.path.append(os.path.abspath(pynpi_lib_path))
    import pynpi.npisys as npisys
    import pynpi.lang as lang

    argv = ["npi", "-dbdir", dbdir]
    if not npisys.init(argv) or not npisys.load_design(argv):
        print("Error: Failed to initialize/load NPI design")
        npisys.end()
        return []

    elab_def_names = set()
    def cb(hdl, data):
        d = hdl.def_name()
        if d:
            data.add(d)
    lang.hier_tree_trv_register_cb('npiModule', cb, elab_def_names)
    lang.hier_tree_trv_register_cb('npiInterface', cb, elab_def_names)
    lang.hier_tree_trv()
    lang.hier_tree_trv_reset_cb()
    npisys.end()

    # Only use NPI to identify unelaborated module-only files to exclude.
    # Everything else (classes, packages, interfaces, defines, headers) is kept.
    module_re = re.compile(r'^\s*module\s+(\w+)', re.MULTILINE)
    other_re  = re.compile(r'^\s*(?:class|package|interface|program)\s+', re.MULTILINE)

    from concurrent.futures import ThreadPoolExecutor

    def classify(fpath):
        try:
            content = open(fpath, errors='ignore').read()
        except:
            return fpath, True  # keep on error
        modules = set(module_re.findall(content))
        if modules and not other_re.search(content) and not (modules & elab_def_names):
            return fpath, False  # exclude: unelaborated module-only file
        return fpath, True

    with ThreadPoolExecutor() as executor:
        results = executor.map(classify, compiled_files)

    used_files = {fpath for fpath, keep in results if keep}
    collector = FileListCollector()
    for f in used_files:
        collector.add(f)
    files = collector.get_sorted()
    print(f"Found {len(files)} unique files in design")
    return files


def _extract_cmdline_items(logfile):
    """Extract command-line items from the first vlogan/vcs Command: block,
    preserving order relative to -f/-file flags.
    Returns (pre_f_items, post_f_items) where each is a list of strings.
    pre_f_items go before the -file/-f section, post_f_items go after."""
    cmd_lines = []
    file_ext_re = re.compile(r'\.(?:sv|v|svh|vh|svp|inc)$', re.IGNORECASE)

    with open(logfile, 'r', errors='ignore') as f:
        in_cmd = False
        for line in f:
            if line.startswith('Command:'):
                in_cmd = True
                line = line[len('Command:'):]
            if in_cmd:
                cmd_lines.append(line.rstrip('\n').rstrip('\\').strip())
                if not line.rstrip().endswith('\\'):
                    break

    cmd_text = ' '.join(cmd_lines)
    tokens = cmd_text.split()

    # Items of interest: +define+, +incdir+, +libext+, +systemverilogext+,
    # -timescale, and direct source files (absolute paths with known extensions)
    def _is_item(tok):
        return (tok.startswith(('+define+', '+incdir+', '+libext+', '+systemverilogext+'))
                or tok.startswith('-timescale')
                or (tok.startswith('/') and file_ext_re.search(tok)))

    # Split into segments: before first -f, between -f's, after last -f
    segments = [[]]  # segments[0] = before first -f
    seen_opts = set()
    seen_files = set()
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if tok in ('-f', '-file'):
            segments.append([])  # start new segment after this -f
            i += 2  # skip -f and its argument
            continue
        if tok == '-timescale' and i + 1 < len(tokens):
            tok = f'-timescale={tokens[i+1]}'
            i += 1
        if _is_item(tok):
            if tok.startswith('/'):
                rp = os.path.realpath(tok)
                if rp not in seen_files:
                    segments[-1].append(tok)
                    seen_files.add(rp)
            else:
                if tok not in seen_opts:
                    segments[-1].append(tok)
                    seen_opts.add(tok)
        i += 1

    pre_f = segments[0] if segments else []
    post_f = [item for seg in segments[1:] for item in seg]
    return pre_f, post_f


def parse_vcs_compile_log(logfile):
    """Parse VCS compile log for 'Parsing' messages and -file/-f contents section"""
    print(f"Parsing VCS compile log: {logfile}")
    
    collector = FileListCollector()
    parsing_pattern = re.compile(
        r"Parsing\s+(?:design\s+file|included\s+file)\s+['\"]([^'\"]+)['\"]|Parsing\s+([^\s]+\.(?:v|sv|vh|svh|svp|inc))",
        re.IGNORECASE
    )
    file_ext_re = re.compile(r'\.\w+$')
    filef_lines = []  # raw lines from -file/-f section
    
    try:
        with open(logfile, 'r', errors='ignore') as f:
            in_filef_section = False
            for line in f:
                # Track -file/-f contents section
                if line.startswith('################# <-file/-f contents>'):
                    in_filef_section = True
                    continue
                if line.startswith('################# <-file/-f ends>'):
                    in_filef_section = False
                    continue

                if in_filef_section:
                    filef_lines.append(line.rstrip('\n'))
                    stripped = line.strip()
                    # Skip options, empty lines, comments, -f refs
                    if not stripped or stripped.startswith(('+', '-', '#')):
                        continue
                    # Only add if it has a file extension (skip directories)
                    if stripped.startswith('/') and file_ext_re.search(stripped):
                        collector.add(stripped)
                    continue

                # Standard Parsing lines
                match = parsing_pattern.search(line)
                if match:
                    filepath = match.group(1) or match.group(2)
                    collector.add(filepath)
    except FileNotFoundError:
        print(f"Error: Log file not found: {logfile}")
        return []
    except Exception as e:
        print(f"Error reading log file: {e}")
        return []
    
    # Extract command-line items, preserving order relative to -f flags
    pre_f, post_f = _extract_cmdline_items(logfile)
    file_ext_re2 = re.compile(r'\.(?:sv|v|svh|vh|svp|inc)$', re.IGNORECASE)
    for item in pre_f + post_f:
        if item.startswith('/') and file_ext_re2.search(item):
            collector.add(item)

    # Save .f file: pre-f items, then -file/-f section, then post-f items
    if filef_lines or pre_f or post_f:
        filef_out = logfile + '.filef.f'
        with open(filef_out, 'w') as fout:
            if pre_f:
                fout.write('// ---- command-line items (before -f) ----\n')
                for item in pre_f:
                    fout.write(f'        {item}\n')
                fout.write('// ---- end command-line (before -f) ----\n')
            for fl in filef_lines:
                stripped = fl.strip()
                if re.match(r'^-f\s+', stripped):
                    fout.write(f'// {stripped}\n')
                else:
                    fout.write(fl + '\n')
            if post_f:
                fout.write('// ---- command-line items (after -f) ----\n')
                for item in post_f:
                    fout.write(f'        {item}\n')
                fout.write('// ---- end command-line (after -f) ----\n')
        print(f"Saved -file/-f section to: {filef_out}")
        if pre_f:
            print(f"  {len(pre_f)} command-line items before -f")
        if post_f:
            print(f"  {len(post_f)} command-line items after -f")

    files = collector.get_sorted()
    print(f"Found {len(files)} unique files in compile log")
    return files


def compare_filelists(design_files, parsed_files, output_file=None):
    """Compare two file lists and show differences"""
    design_set = set(design_files)
    parsed_set = set(parsed_files)
    
    common = design_set & parsed_set
    only_design = design_set - parsed_set
    only_parsed = parsed_set - design_set
    
    # Prepare output
    lines = []
    lines.append("=" * 80)
    lines.append("FILE LIST COMPARISON REPORT")
    lines.append("=" * 80)
    lines.append(f"\nTotal files in design (NPI):     {len(design_files)}")
    lines.append(f"Total files in compile log:      {len(parsed_files)}")
    lines.append(f"Common files:                    {len(common)}")
    lines.append(f"Only in design (used):           {len(only_design)}")
    lines.append(f"Only in compile log (unused):    {len(only_parsed)}")
    
    if common:
        lines.append(f"\n{'-'*80}")
        lines.append(f"COMMON FILES ({len(common)}):")
        lines.append('-'*80)
        for f in sorted(common):
            lines.append(f)
    
    if only_design:
        lines.append(f"\n{'-'*80}")
        lines.append(f"ONLY IN DESIGN - Used by elaboration ({len(only_design)}):")
        lines.append('-'*80)
        for f in sorted(only_design):
            lines.append(f)
    
    if only_parsed:
        lines.append(f"\n{'-'*80}")
        lines.append(f"ONLY IN COMPILE LOG - Not used by elaboration ({len(only_parsed)}):")
        lines.append('-'*80)
        for f in sorted(only_parsed):
            lines.append(f)
    
    lines.append("\n" + "=" * 80)

    report = "\n".join(lines)

    # Write to file first
    if output_file:
        with open(output_file, 'w') as f:
            f.write(report)
        print(f"Report written to: {output_file}")

    # Print only summary to console
    summary_end = report.index("\n" + "-"*80) if "-"*80 in report else len(report)
    print(report[:summary_end])


def save_filelist(files, output_file):
    """Save sorted, deduplicated file list for tkdiff"""
    with open(output_file, 'w') as f:
        f.write('\n'.join(sorted(set(files))) + '\n')
    print(f"Saved {len(files)} files to: {output_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Analyze VCS compile to find actual files used vs parsed",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract design files only
  %(prog)s --dbdir simv.daidir --design-out design_files.txt
  
  # Parse compile log only
  %(prog)s --compile-log vcs.log --parsed-out parsed_files.txt
  
  # Compare both
  %(prog)s --dbdir simv.daidir --compile-log vcs.log --compare-out report.txt
        """
    )
    
    parser.add_argument('--dbdir', help='Path to simv.daidir for NPI analysis')
    parser.add_argument('--compile-log', help='Path to VCS compile log file')
    parser.add_argument('--design-out', default='design_files.txt', help='Output file for design files list (default: design_files.txt)')
    parser.add_argument('--parsed-out', default='parsed_files.txt', help='Output file for parsed files list (default: parsed_files.txt)')
    parser.add_argument('--compare-out', default='comparison_report.txt', help='Output file for comparison report (default: comparison_report.txt)')
    parser.add_argument('--metadumpfile', help='File containing list of all files needed for compile (one per line)')
    parser.add_argument('--meta-match-out', default='metadump_matching.txt', help='Output file for metadump files found in compile/parse logs (default: metadump_matching.txt)')
    parser.add_argument('--meta-extra-out', default='metadump_extra.txt', help='Output file for metadump files NOT found in compile/parse logs (default: metadump_extra.txt)')
    parser.add_argument('--prune-filef', action='store_true', help='Prune the .f file: comment all source files, then uncomment those in metadump + files with global defines/macros/structs')
    
    args = parser.parse_args()
    
    if not args.dbdir and not args.compile_log and not args.metadumpfile:
        parser.error("At least one of --dbdir, --compile-log, or --metadumpfile must be specified")
    
    design_files = []
    parsed_files = []
    
    # Extract design files
    if args.dbdir:
        design_files = extract_design_files_npi(args.dbdir)
        if design_files:
            save_filelist(design_files, args.design_out)

    # Parse compile log
    if args.compile_log:
        parsed_files = parse_vcs_compile_log(args.compile_log)
        if parsed_files:
            save_filelist(parsed_files, args.parsed_out)

    # Compare if both available
    if design_files and parsed_files:
        compare_filelists(design_files, parsed_files, args.compare_out)
    elif not design_files and args.dbdir:
        print("Warning: No design files extracted")
    elif not parsed_files and args.compile_log:
        print("Warning: No parsed files found in log")

    # Metadump cross-check against compile/parse logs
    if args.metadumpfile:
        cross_check_metadump(args.metadumpfile, design_files, parsed_files,
                             args.meta_match_out, args.meta_extra_out)

    # Prune .f file
    if args.prune_filef:
        if not args.compile_log:
            parser.error("--prune-filef requires --compile-log")
        if not args.metadumpfile:
            parser.error("--prune-filef requires --metadumpfile")
        filef_path = args.compile_log + '.filef.f'
        if not os.path.exists(filef_path):
            print(f"Error: {filef_path} not found. Run without --prune-filef first.")
        else:
            meta_files = parse_metadumpfile(args.metadumpfile) if not args.metadumpfile else parse_metadumpfile(args.metadumpfile)
            prune_filef(filef_path, meta_files)


def _strip_comments(content):
    """Remove // and /* */ comments from SV/V content."""
    content = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
    content = re.sub(r'//.*', '', content)
    return content


def _strip_sv_bodies(content):
    """Remove content inside module/class/package/interface/program...end* blocks
    using a simple nesting-aware scanner instead of fragile regex."""
    keywords = {'module', 'class', 'package', 'interface', 'program'}
    end_keywords = {'endmodule', 'endclass', 'endpackage', 'endinterface', 'endprogram'}
    tokens = re.finditer(r'\b(\w+)\b', content)
    depth = 0
    last_end = 0
    result = []
    for m in tokens:
        word = m.group(1)
        if word in keywords and depth == 0:
            result.append(content[last_end:m.start()])
            depth = 1
        elif word in keywords and depth > 0:
            depth += 1
        elif word in end_keywords and depth > 0:
            depth -= 1
            if depth == 0:
                last_end = m.end()
    if depth == 0:
        result.append(content[last_end:])
    return ''.join(result)


def scan_file_content(filepath):
    """Scan a file and return (has_global, macros_defined, macros_used).
    has_global: True if file has global defines/macros/typedefs/structs outside
    SV constructs, OR contains interface/program definitions (these are type
    definitions that other files depend on but -metadump_txt omits them).
    macros_defined: set of macro names defined by this file
    macros_used: set of macro names used by this file (backtick references)
    """
    try:
        raw = open(filepath, 'r', errors='ignore').read()
    except:
        return False, set(), set()

    stripped = _strip_comments(raw)

    # Collect all `define MACRO_NAME in the file (at any scope - defines are global in SV)
    macros_defined = set(re.findall(r'`define\s+(\w+)', stripped))

    # Collect all `MACRO_NAME usages (exclude compiler directives)
    sv_directives = {
        'define', 'undef', 'ifdef', 'ifndef', 'else', 'elsif', 'endif',
        'include', 'timescale', 'resetall', 'celldefine', 'endcelldefine',
        'default_nettype', 'pragma', 'line', 'begin_keywords', 'end_keywords',
        'unconnected_drive', 'nounconnected_drive', 'protect', 'endprotect',
    }
    all_backtick = set(re.findall(r'`(\w+)', stripped))
    macros_used = all_backtick - sv_directives - macros_defined

    # Check for global content outside SV construct bodies
    outside = _strip_sv_bodies(stripped)

    global_re = re.compile(
        r'^\s*(?:'
        r'`(?:define|ifdef|ifndef|include|undef|timescale)\b|'
        r'typedef\b|'
        r'struct\b|'
        r'union\b|'
        r'enum\b|'
        r'parameter\b|'
        r'localparam\b|'
        r'const\b|'
        r'import\b'
        r')',
        re.MULTILINE
    )
    has_global = bool(global_re.search(outside))

    # Interface/program definitions are type defs other files depend on.
    # -metadump_txt omits them, so always keep these files.
    if not has_global:
        has_global = bool(re.search(
            r'^\s*(?:interface|program)\b', stripped, re.MULTILINE))

    return has_global, macros_defined, macros_used


def prune_filef(filef_path, meta_files):
    """Prune .f file: comment all source files, uncomment those in metadump,
    files with global defines/macros/structs, and files that define macros
    needed by kept files (dependency chain)."""
    import shutil
    from concurrent.futures import ThreadPoolExecutor

    backup = filef_path + '.bak'
    shutil.copy2(filef_path, backup)
    print(f"Backup saved to: {backup}")

    file_ext_re = re.compile(r'\.\w+$')
    meta_resolved = set()
    for f in meta_files:
        meta_resolved.add(os.path.realpath(f))

    # Collect all source file paths from the .f file, tracking -v prefixes
    lines = open(filef_path, 'r').readlines()
    all_src_files = {}  # line_idx -> resolved_path
    src_prefix = {}     # line_idx -> index of preceding -v line (or None)
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or stripped.startswith(('//', '+', '#')):
            continue
        if stripped.startswith('/') and file_ext_re.search(stripped):
            all_src_files[i] = os.path.realpath(stripped)
            # Check if preceded by a standalone -v line
            for j in range(i - 1, -1, -1):
                prev = lines[j].strip()
                if not prev or prev.startswith('//'):
                    continue
                if prev == '-v':
                    src_prefix[i] = j
                break

    # Scan ALL source files in parallel for global content + macro info
    unique_paths = set(all_src_files.values())
    print(f"Scanning {len(unique_paths)} source files for global content and macro dependencies...")
    with ThreadPoolExecutor() as executor:
        scan_results = dict(executor.map(
            lambda p: (p, scan_file_content(p)),
            unique_paths
        ))
    # scan_results: path -> (has_global, macros_defined, macros_used)

    # Build macro define map: macro_name -> set of files that define it
    macro_definers = {}  # macro_name -> set(resolved_path)
    for path, (_, defs, _) in scan_results.items():
        for m in defs:
            macro_definers.setdefault(m, set()).add(path)

    # Determine initial keep set: metadump files + files with global content
    keep_set = set()
    global_set = set()
    for path, (has_global, _, _) in scan_results.items():
        if path in meta_resolved:
            keep_set.add(path)
        elif has_global:
            keep_set.add(path)
            global_set.add(path)

    # Iteratively resolve macro dependencies:
    # If a kept file uses macro X, and file F defines X, keep F too
    changed = True
    macro_dep_set = set()
    while changed:
        changed = False
        needed_macros = set()
        for path in keep_set:
            _, _, used = scan_results.get(path, (False, set(), set()))
            needed_macros |= used
        for macro in needed_macros:
            for definer in macro_definers.get(macro, set()):
                if definer not in keep_set:
                    keep_set.add(definer)
                    macro_dep_set.add(definer)
                    changed = True

    # Rewrite the file: handle -v prefix lines and dedup
    uncommented_meta = 0
    kept_global_cnt = 0
    kept_macro_dep = 0
    commented = 0
    deduped = 0
    comment_lines = set()  # line indices to comment out (includes -v lines)
    seen_paths = set()     # for deduplication

    for i in sorted(all_src_files):
        resolved = all_src_files[i]
        # Deduplicate: comment out subsequent occurrences
        if resolved in seen_paths:
            comment_lines.add(i)
            if i in src_prefix:
                comment_lines.add(src_prefix[i])
            deduped += 1
            continue
        seen_paths.add(resolved)

        if resolved in keep_set:
            if resolved in meta_resolved:
                uncommented_meta += 1
            elif resolved in macro_dep_set:
                kept_macro_dep += 1
            elif resolved in global_set:
                kept_global_cnt += 1
        else:
            comment_lines.add(i)
            if i in src_prefix:
                comment_lines.add(src_prefix[i])
            commented += 1

    out_lines = []
    for i, line in enumerate(lines):
        if i in comment_lines:
            indent = line[:len(line) - len(line.lstrip())]
            out_lines.append(f"{indent}// {line.strip()}\n")
        else:
            out_lines.append(line)

    with open(filef_path, 'w') as f:
        f.writelines(out_lines)

    print(f"\nPrune results for {filef_path}:")
    print(f"  Uncommented (in metadump):       {uncommented_meta}")
    print(f"  Uncommented (global content):    {kept_global_cnt}")
    print(f"  Uncommented (macro dependency):  {kept_macro_dep}")
    print(f"  Commented out:                   {commented}")
    if deduped:
        print(f"  Deduplicated:                    {deduped}")


def parse_metadumpfile(metadumpfile):
    """Read metadump file and return set of resolved file paths"""
    collector = FileListCollector()
    try:
        with open(metadumpfile, 'r', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    collector.add(line)
    except FileNotFoundError:
        print(f"Error: Metadump file not found: {metadumpfile}")
        return set()
    files = set(collector.get_sorted())
    print(f"Found {len(files)} unique files in metadump file")
    return files


def cross_check_metadump(metadumpfile, design_files, parsed_files, match_out, extra_out):
    """Cross-check metadump files against compile/parse log files"""
    meta_files = parse_metadumpfile(metadumpfile)
    if not meta_files:
        return

    log_files = set(design_files) | set(parsed_files)
    if not log_files:
        print("Warning: No compile/parse log files to cross-check against")

    matching = sorted(meta_files & log_files)
    extra = sorted(meta_files - log_files)

    save_filelist(matching, match_out)
    save_filelist(extra, extra_out)

    print(f"\nMetadump cross-check: {len(matching)} matching, {len(extra)} extra (not in compile/parse logs)")


if __name__ == "__main__":
    main()
